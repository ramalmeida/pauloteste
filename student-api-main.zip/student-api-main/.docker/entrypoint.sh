#!/bin/bash

npm install

npm run typeorm migration:run

npm i --save @nestjs/config

npm i typeorm@0.2

npm i --save @nestjs/config

npm i @nestjs/typeorm

npm install pg --save

npm run start:dev